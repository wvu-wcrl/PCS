2/1/2012

To run compiled CML with FSK simulation,

> ./run_SingleSimulate.sh /home/tferrett/mcr/v713
